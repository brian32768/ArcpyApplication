config.py    in real life you'd have one config.py for your entire Visual Studio 'Solution'
README.md    this file
tool.py      template for business logic code for an individual tool
ToolBox.pyt  template for code that ArcCatalog reads to define it all as a toolbox 
toolclass.py This defines a class that can be included in the ToolBox and calls the business logic

If you are putting more than one tool in a toolbox, then you'd
first create a new project and then use 'add new item' to add tool classes
and then 'add new item' to add more business logic python files.